/*
Name: 			App Landing
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	7.2.0
*/

(function( $ ) {

	

}).apply( this, [ jQuery ]);